<div class="container-fluid">
    <div class="row">
        {{-- STEP 1: Trips Table + Assign Panel --}}
        <div id="assignStep1" class="w-100">
            <div class="row">
                <!-- LEFT: Trips Table -->
                <div class="col-xl-8">
                    <div class="d-flex align-items-start justify-content-between mb-2">
                        <div>
                            <h6 class="mb-1">Select Trips</h6>
                            <p class="selectedtrip text-muted">Choose trips to assign</p>
                        </div>
                    </div>

                    <div style="max-height:520px; overflow:auto;">
                        <table class="table table-sm table-bordered w-100" id="assignTripsTable">
                            <thead>
                                <tr>
                                    <th><input type="checkbox" id="selectAllTrips"></th>
                                    <th>Trip ID</th>
                                    <th>Delivery Date</th>
                                    <th>To Location</th>
                                    <th>Quantity</th>
                                    <th>Pickup</th>
                                    <th>Updates</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>

                <!-- RIGHT: Assign Panel -->
                <div class="col-xl-4">
                    <div class="p-3 border rounded">
                        <h6 class="mb-3">Assign Vehicle & Driver</h6>

                        <p class="mb-1"><strong>Vehicle Category</strong></p>
                        <select id="vehicleCategory" class="form-control mb-3">
                            <option value="">- Select Category -</option>
                        </select>

                        <p class="mb-1"><strong>Vehicle Type</strong></p>
                        <select id="vehicleType" class="form-control mb-3">
                            <option value="">- Select Vehicle Type -</option>
                        </select>

                        <p class="mb-1"><strong>Select Product</strong></p>
                        <select id="productSelect" class="form-control mb-3">
                            <option value="">- Select Product -</option>
                        </select>

                        <p class="mb-1"><strong>Vehicle Number</strong></p>
                        <input id="vehicleNumber" type="text" class="form-control mb-3" placeholder="Search Vehicle Number">

                        <div class="border p-2 mb-3">
                            <p><strong>Vehicle Type:</strong> <span id="summaryVehicleType">-</span></p>
                            <p><strong>Vehicle Capacity:</strong> <span id="summaryVehicleCapacity">-</span></p>
                            <p><strong>Added Quantity:</strong> <span id="summaryAddedQty">-</span></p>
                            <p><strong>Balance Quantity:</strong> <span id="summaryBalanceQty">-</span></p>
                        </div>

                        <p class="mb-1"><strong>Driver Name</strong></p>
                        <input id="driverName" type="text" class="form-control mb-3" placeholder="Search Driver Name">

                        <p class="mb-1"><strong>Phone</strong></p>
                        <input id="driverPhone" type="text" class="form-control mb-3" readonly placeholder="Auto filled by Driver">

                        <p class="mb-1"><strong>Salary Type</strong></p>
                        <select id="salaryType" class="form-control mb-3">
                            <option value="">- Select Salary -</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Footer Buttons -->
            <div class="mt-3 d-flex justify-content-start">
                <button type="button" class="btn btn-primary mr-2" id="continueAssignBtn">Continue</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            </div>
        </div>

        {{-- STEP 2 --}}
        <div id="assignStep2" class="w-100" style="display:none;">
            <div class="text-center py-5">
                <h4 id="assignStep2Message">You have selected X trips.</h4>
                <p class="text-muted">Proceed with assignment or go back to change selections.</p>

                <div class="mt-4">
                    <button type="button" class="btn btn-secondary mr-2" id="backToStep1">Back</button>
                    <button type="button" class="btn btn-success" id="finalizeAssignBtn">Finalize & Assign</button>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
assignTable = $('#assignTripsTable').DataTable({
    processing: true,
    serverSide: true,
    ajax: {
      url: '{{ route("logistics.trip.getData") }}', // same as index
      data: function (d) {
        // add filters if needed
      }
    },
    pageLength: 25,
    lengthChange: false,
    order: [[1, 'asc']], 
    columns: [
      {
        data: 'id',
        name: 'select',
        orderable: false,
        searchable: false,
        render: function(data, type, row, meta) {
          return '<input type="checkbox" class="select-row" data-id="' + data + '">';
        }
      },
      { data: 'trip_code', name: 'trip_code' },
      { data: 'delivery_date', name: 'delivery_date' }, // already formatted dd-mm-YYYY in controller
      { data: 'to_location', name: 'to_location' },
      { data: 'total_quantity', name: 'total_quantity' },
      { data: 'pickup_point_flag', name: 'pickup_point_flag' },
      { data: 'updates', name: 'updates', orderable: false, searchable: false },
      { data: 'status', name: 'status', orderable: false, searchable: false }
    ]
});
</script>