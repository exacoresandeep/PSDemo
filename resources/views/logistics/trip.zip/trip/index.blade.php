@extends('layouts.app')

@section('content')
<div class="activity-sec">
    <div class="inner-header button-align">
        <h3>Trip Management</h3>
        <button type="button" class="btn btn-primary" id="openCreateTripModal">
            Create Trip
        </button>
    </div>

    <!-- Filters -->
    <div class="filter-sec target-filter">
        <div class="row mb-2">
            <div class="col-md-2">
                <label>Date</label>
                <input type="text" id="searchDate" class="form-control" placeholder="DD/MM/YYYY">
            </div>
            <div class="col-md-2">
                <label>Driver Name</label>
                <input type="text" id="searchDriverName" class="form-control" placeholder="Search Driver Name">
            </div>
            <div class="col-md-2">
                <label>Vehicle Number</label>
                <input type="text" id="searchVehicleNumber" class="form-control" placeholder="Search Vehicle No">
            </div>
        </div>
    </div>

    <!-- Table -->
    <div class="listing-sec">
        <table class="table table-bordered table-striped w-100" id="tripsTable">
            <thead>
                <tr>
                    <th>Sl.No</th>
                    <th>Trip ID</th>
                    <th>Delivery Date</th>
                    <th>To Location</th>
                    <th>Quantity</th>
                    <th>Pickup</th>
                    <th>Updates</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</div>

<!-- Create Trip Modal -->
<div class="modal fade" id="createTripModal" tabindex="-1" role="dialog" aria-labelledby="createTripModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="createTripModalLabel">Create Trip</h5>
        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="createTripModalBody">
        <div class="text-center">
          <i class="fa fa-spinner fa-spin fa-2x"></i> Loading...
        </div>
      </div>
    </div>
  </div>
</div>
@endsection

@section('scripts')
<script>
$(document).ready(function() {
    // Main Trips Table
    let table = $('#tripsTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: '{{ route("logistics.trip.getData") }}',
            data: function (d) {
                d.date = $('#searchDate').val();
                d.driver = $('#searchDriverName').val();
                d.vehicle_no = $('#searchVehicleNumber').val();
            }
        },
        columns: [
            { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
            { data: 'id', name: 'id' },
            { data: 'delivery_date', name: 'delivery_date' },
            { data: 'to_location', name: 'to_location' },
            { data: 'total_quantity', name: 'total_quantity' },
            { data: 'pickup_point_flag', name: 'pickup_point_flag' },
            { data: 'updates', name: 'updates' },
            { data: 'status', name: 'status' },
            { data: 'action', name: 'action' }
        ]
    });

    // Redraw table on filter change
    $('#searchDate, #searchDriverName, #searchVehicleNumber').on('change keyup', function () {
        table.draw();
    });

    // Open Create Modal and Load Blade
    $('#openCreateTripModal').on('click', function() {
        $('#createTripModal').modal('show');
        $('#createTripModalBody').load('{{ route("logistics.trip.create") }}');
    });

    // Delegated handlers for dynamically loaded modal content

    // Continue button → go to Step 2
    $(document).on('click', '#continueAssignBtn', function() {
        let selected = [];
        $('#assignTripsTable .select-row:checked').each(function() {
            selected.push($(this).data('id'));
        });

        let message = selected.length === 0 
            ? 'No trips selected. You can go back and select trips.' 
            : 'You have selected ' + selected.length + ' trip' + (selected.length > 1 ? 's' : '') + '.';

        $('#assignStep2Message').text(message);
        $('#assignStep1').hide();
        $('#assignStep2').show();
    });

    // Back button
    $(document).on('click', '#backToStep1', function() {
        $('#assignStep2').hide();
        $('#assignStep1').show();
    });

    // Finalize button
    $(document).on('click', '#finalizeAssignBtn', function() {
        alert('Finalize assignment - Implement AJAX call here.');
    });

    // Reset modal when closed
    $('#createTripModal').on('hidden.bs.modal', function() {
        $('#assignStep2').hide();
        $('#assignStep1').show();
    });
});
</script>
@endsection
